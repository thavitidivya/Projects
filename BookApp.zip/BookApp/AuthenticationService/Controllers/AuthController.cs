﻿using AuthenticationService.Models;
using AuthenticationService.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AuthenticationService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthservice _authservice;
        public AuthController(IAuthservice authservice)
        {
            _authservice = authservice;
        }
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Registermodel model)
        {
            var result = await _authservice.Register(model);
            if (!result.Success)
                return BadRequest(result.Message);
            return Ok(result);
        }
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Loginmodel model)
        {
            var result = await _authservice.login(model);
            if (!result.success)
                return Unauthorized(result.Message);
            return Ok(new { Token = result.Token });
        }
    }
}
