﻿namespace AuthenticationService.Models
{
    public class Loginmodel
    {
        public string  UserName { get; set; }
        public string Password { get; set; }
    }
}
