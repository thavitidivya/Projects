﻿using AuthenticationService.Models;

namespace AuthenticationService.Service
{
    public interface IAuthservice
    {
        Task<AuthResult> Register(Registermodel model);
        Task<AuthResult> login(Loginmodel model);
    }
}
